
#include <windows.h>
#include <vfw.h>

int main()
{
  AVIFileInit();
  AVIFileExit();
  return 0;
}
